@echo off
echo ========================================
echo Audio Cleaner - Flutter Setup
echo ========================================
flutter create .
flutter pub get
echo.
echo Setup finished.
echo To build APK:
echo flutter build apk --release
pause
